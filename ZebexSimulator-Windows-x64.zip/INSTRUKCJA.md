# Zebex Simulator — prototyp Windows

Aplikacja EXE do wypróbowania zbierania kodów i ilości przed zakupem kolektora. Nie wymaga Pythona ani osobnej instalacji .NET. Docelowo Windows 10/11 x64.

**Zgodność z SUZ / Subiektem nexo nie jest jeszcze potwierdzona. Program nie implementuje protokołu Zebex Z-9000.** Nie zastępuje urządzenia w sterowniku SUZ i nie jest produktem ZEBEX ani InsERT. Nie należy podejmować decyzji zakupowej o zgodności sprzętu na podstawie tego prototypu.

## Uruchomienie

1. Rozpakuj paczkę i uruchom `ZebexSimulator.exe` na Windows x64.
2. W zakładce **Odczyty i ilości** wpisz kod, ilość i naciśnij Enter. Powtórzenie kodu sumuje ilości; zera na początku kodu są zachowane.
3. Zapisz sesję JSON, aby odtworzyć ją później. Odczyty w pamięci nie są automatycznie zapisywane.
4. Eksport CSV (średnik) i TSV (tabulator) zapisuje UTF-8 z BOM, nagłówek `Kod` / `Ilosc` i ilości z kropką dziesiętną. Są to ogólne formaty wymiany, **nie potwierdzone formaty importu SUZ/nexo**.

## Diagnostyka komunikacji SUZ

Do połączenia dwóch programów na jednym komputerze potrzebna jest wirtualna para portów COM. Ta aplikacja nie instaluje sterownika portów. Użyj sterownika obsługującego Twoją wersję Windows i z poprawnym podpisem; nie wyłączaj sprawdzania podpisów sterowników.

1. Utwórz parę portów, np. COM10 ↔ COM11.
2. W ustawieniach kolektora SUZ wybierz jeden port; w zakładce **Diagnostyka SUZ / COM** drugi. Nie otwieraj tego samego portu w obu aplikacjach.
3. Dopasuj prędkość, bity danych, parzystość, bity stopu i sterowanie przepływem do ustawień SUZ. Domyślne 9600/8/N/1 nie są zweryfikowaną konfiguracją Z-9000.
4. Kliknij **Połącz** i zainicjuj komunikację w SUZ. Log RX wyświetla otrzymane bajty HEX. Granice wpisów logu są porcjami odczytu portu, nie granicami pakietów protokołu.
5. Możesz ręcznie wysyłać bajty HEX lub tekst ASCII (bez automatycznego zakończenia linii). Program nie odpowiada automatycznie na żądania SUZ. Brak odpowiedzi lub błąd wykrywania urządzenia są oczekiwane na tym etapie.
6. Zapisz log. Do opracowania zgodnego profilu potrzebne są również wersja SUZ, nazwa wybranego sterownika, parametry portu oraz specyfikacja protokołu albo wiarygodny zapis odpowiedzi prawdziwego urządzenia. Same żądania SUZ mogą nie wystarczyć do odtworzenia odpowiedzi.

Testuj na środowisku testowym Subiekta. Program nie łączy się z bazą danych, nie tworzy dokumentów i nie wysyła listy odczytów do SUZ.

## Budowanie ze źródeł

Zainstaluj .NET SDK 8 i uruchom `build-windows.ps1` w PowerShell. Wynik to `artifacts/windows-x64/ZebexSimulator.exe`, samodzielny plik z dołączonym środowiskiem .NET. Pakiet nie jest podpisany certyfikatem wydawcy.

Na Linux można zbudować pakiet Windows tym samym poleceniem `dotnet publish` ze skryptu. Logikę danych sprawdza `dotnet run --project tests/Zebex.Checks -c Release`. Interfejs Windows i połączenie COM wymagają osobnej walidacji na Windows; kompilacja na Linux nie potwierdza działania SUZ.
